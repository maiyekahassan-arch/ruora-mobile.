RUORA MOBILE — QUICK START

Contents
- index.html: the mobile-friendly app
- manifest.webmanifest: installable PWA metadata
- sw.js: offline cache service worker

IMPORTANT
This is an educational demo using locally generated synthetic prices.
It is not connected to live Forex data, MT5, a broker, or trade execution.
Signals are illustrative only and must not be used for real trading.

OPEN ON ANDROID
1. Extract RUORA_Mobile.zip.
2. To preview, open index.html in a browser/file viewer if your phone permits.
3. For true PWA installation, the files must be hosted on an HTTPS web server.
4. Open the HTTPS address in Chrome on Android.
5. Use Chrome menu > Add to Home screen (or Install app, if shown).

A local file:// preview generally cannot install as a PWA because service workers
and web app installation require a secure origin (HTTPS or localhost).
